# Examen de Data Science — Colab + GitHub

Este repositorio contiene tu examen convertido a un **notebook ejecutable en Google Colab** (`Examen_DS_Colab.ipynb`), con ejemplos prácticos: Teorema de Bayes, PPV con sensibilidad/especificidad, selección de umbral por costos (TPR/FPR), ROC/PR, regularización (Ridge/Lasso), overfitting y trade-off sesgo–varianza.

## Estructura
```
.
├── Examen_DS_Colab.ipynb
├── README.md
├── requirements.txt
└── .gitignore
```

## Requisitos (uso local opcional)
- Python 3.10+
- Paquetes en `requirements.txt`

Instalación (local):
```bash
python -m venv .venv
source .venv/bin/activate  # en Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Ejecutar en Google Colab
1. Abre [colab.research.google.com](https://colab.research.google.com/).
2. `Archivo → Subir cuaderno` y selecciona `Examen_DS_Colab.ipynb`.
3. Ejecuta la celda de **Instalación** (si aparece una advertencia de dependencias).
4. Corre las secciones 1→10 en orden.

> **Sugerencia:** Una vez subido a tu GitHub, podrás abrir Colab directamente desde el repo con `Archivo → Abrir cuaderno → GitHub`, pegando la URL del repo.

## Guardar en GitHub (opción sencilla — Web)
1. Crea un repositorio nuevo (p.ej. `examen-ds-colab`).
2. Haz clic en **Add file → Upload files**.
3. Sube `Examen_DS_Colab.ipynb`, `README.md`, `requirements.txt` y `.gitignore`.
4. Escribe un mensaje de *commit* y confirma.

## Guardar en GitHub (opción con Git)
```bash
git clone https://github.com/TU_USUARIO/examen-ds-colab.git
cd examen-ds-colab
# Copia los archivos al directorio del repo
cp /ruta/a/Examen_DS_Colab.ipynb .
cp /ruta/a/README.md .
cp /ruta/a/requirements.txt .
cp /ruta/a/.gitignore .

git add .
git commit -m "Add exam Colab notebook and docs"
git push origin main  # o 'master' según tu repo
```

## Guardar desde Colab a GitHub
En Colab: `Archivo → Guardar una copia en GitHub`.  
- Autoriza tu cuenta de GitHub.  
- Elige el repositorio y confirma el *commit*.

## Notas
- En el notebook encontrarás: ejemplos ejecutables, snippets para **seleccionar umbral por costos**, demos de **Ridge/Lasso** y **overfitting**.
- Si deseas, agrega un *badge* de Colab al README cuando tengas la URL real del repo:
  ```markdown
  [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/TU_USUARIO/examen-ds-colab/blob/main/Examen_DS_Colab.ipynb)
  ```

---

**¡Éxitos en tu examen y entrevistas!**